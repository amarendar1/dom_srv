import pandas as pd
import pyedds
import time
import urllib3
from datetime import datetime
import sys
import utils
import cx_Oracle
import os
import json
from pandas import DataFrame
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# import utils_1 as ut
import utils as ut


#worked as of 06/29/2020

##### Variables used in script ########

load_type="INIT_LOAD"
MIN_EPOCH = 000000000000
SRC_SYSTEM_CD = 'BILLING_GWBC'
environment = ut.getinipath('E1P_API/DefaultENV')
print(environment)


class GeneralException(Exception):

    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message

##### Variables used in script ########

#To Read json
def read_json(filename):
    print("started reading the json file")
    try:
        df= pd.read_json(filename,dtype=False,encoding='latin-1')               
        return df
    except:
        df= pd.read_json(filename, typ='series',dtype=False,encoding='latin-1')
        return df

#Loading to Oracle from dataframe
def load_to_db(df,table_name):

    print("loading data to database")   

    ##### derive the existing columns
    try:       
        
        sql_stmt="select LISTAGG((CASE WHEN COLUMN_NAME like 'HEADER__%' THEN LOWER(COLUMN_NAME ) ELSE COLUMN_NAME  END),',') WITHIN GROUP (ORDER BY TABLE_NAME) from all_tab_columns  WHERE OWNER='DATAHUB_EDDS' AND TABLE_NAME='"+table_name.split('.')[1]+"'"
        sql_checksum="SELECT (LISTAGG(COLUMN_NAME, '||') WITHIN GROUP (ORDER BY TABLE_ID)) FROM DATAHUB_EDDS.EDDS_HDS_CONFIG_COLUMNS WHERE COLUMN_NAME!='SPATIALPOINT' AND DATA_TYPE!='CLOB' AND TABLE_NAME='"+table_name.split('.')[1]+"'"    
        g_cursor.execute(sql_stmt)
        df1 = DataFrame(g_cursor.fetchall())
        columns_existing=str(df1.iloc[0,0]).strip(' ')
        columns_existing=columns_existing.split(',')
        g_cursor.execute(sql_checksum)
        dfchecksum = DataFrame(g_cursor.fetchall())
        columns_checksum=str(dfchecksum.iloc[0,0]).strip(' ')        
        
    except Exception as e:
        print(str(e))
    ##### derive the existing columns

    ##### dataframe columns
    df.columns = [x.upper().strip(' ') for x in df.columns]
    df_columns=list(df.columns)
    ##### dataframe columns

    ##### columns that to be dropped that is not present in table but in json
    columns_existing= [x.upper().strip(' ') for x in columns_existing]    
    cols_missing=list(set(df_columns) - set(columns_existing))

    try:
        col_mis_check=0
        for c in cols_missing:
            if str(c).startswith('__S3') or str(c).startswith('ETL_'):
                pass
            else:
                col_mis_check=1
        if col_mis_check==1:
            send_email("Missing columns in table-"+table_name,"Columns missing in table "+str(cols_missing)+" .There is Discrepency Between Columns in JSON from s3(billing_gwbc) Vs Landing Table.Please investiage and take necessary action")
    except:
        print("unable to send email")

    #print("Columns missing in table "+str(cols_missing))
    
    df=df.drop(cols_missing, axis = 1)

    ##### common columns in table and dataframe
    success_records = 0
    reject_records = 0
    cols = ",".join([str(i) for i in df.columns.tolist()])
    sql_truncate_table="TRUNCATE TABLE " + table_name
    g_cursor.execute(sql_truncate_table)
    # Insert DataFrame records one by one.

    for i,row in df.iterrows():        
        sql = "INSERT INTO " + table_name + " (" + cols + ") VALUES " + str(tuple(row)).replace('"TO_TIMESTAMP','TO_TIMESTAMP').replace('HH24:MI:SS.FF\')"', 'HH24:MI:SS.FF\')').replace(', None',',null').replace('None,','null,').replace(', nan',',null').replace('nan,','null,')
        #print(sql)
        try:
            g_cursor.execute(sql)
            success_records = success_records + 1
        except Exception as e:
            # print(str(tuple(row)))
            # print(sql)
            try:
                t = sql
                si = 0
                while (True):
                    sq_i = t.find('"', si)
                    if sq_i < 0:
                        break
                    eq_i = t.find('"', sq_i + 1)
                    t = t[0:sq_i] + "'" + str(t[sq_i + 1:eq_i]).replace("'", "''") + "'" + t[eq_i + 1:]
                    si = eq_i + 1

                g_cursor.execute(t)
                success_records = success_records + 1
            except Exception as e:
                # print(t)
                # print(sql)
                try:
                    l = []
                    for ti in tuple(row):
                        if "TO_TIMESTAMP" not in str(ti).upper() and "'" in str(ti) and '"' in str(ti):
                            l.append(str(ti).replace("'", "''").replace('"',"''"))
                        else:
                            l.append(ti)

                    t = tuple(l)
                    sql = "INSERT INTO " + table_name + " (" + cols + ") VALUES " + str(t).replace('"TO_TIMESTAMP',
                                                                                                   'TO_TIMESTAMP').replace(
                        'HH24:MI:SS.FF\')"', 'HH24:MI:SS.FF\')').replace(', None', ',null').replace('None,',
                                                                                                    'null,').replace(
                        ', nan', ',null').replace('nan,', 'null,')
                    #print(sql)
                    t = sql
                    si = 0
                    while (True):
                        sq_i = t.find('"', si)
                        if sq_i < 0:
                            break
                        eq_i = t.find('"', sq_i + 1)
                        t = t[0:sq_i] + "'" + str(t[sq_i + 1:eq_i]).replace("'", "''") + "'" + t[eq_i + 1:]
                        si = eq_i + 1
                    t.replace('"',"'")
                    g_cursor.execute(t)
                    # print(str(sql).replace("\'","''"))
                    #g_cursor.execute(str(sql))

                except Exception as e1:
                    print(str(e1))
            # writing reject records to reject table
                    print("Rejected the record Insertion "+str(e))
                    reject_records=reject_records+1
            #rejsql=""
            #g_cursor.execute(rejsql)
    sql_str="UPDATE " + table_name + " SET ETL_CHECKSUM = standard_hash("+columns_checksum+")"
    #print(sql_str)
    g_cursor.execute(sql_str)
    print(success_records)
    print(reject_records)
    if success_records==len(df):
        return [True,success_records,reject_records]
    else:
        return [False,success_records,reject_records]    
    print('Completed loading of JSON data to database')
    print(os.path.join(r, file))

def correct_json_files(thisdir):
    print("Correcting json files started")
    corrected_json_files_lst=[]
    for r, d, f in os.walk(thisdir):
        for file in f:
            read_flag=0
            if file.lower().endswith(".json") and not file.lower().startswith('corrected_'):    
                file_r = open(os.path.join(r, file),"r") 
                file_w=open(os.path.join(r, 'corrected_'+file),"w")        
                try: 
                    file_r_lines=file_r.readlines()
                    if len(file_r_lines) > 1:
                        rc=0
                        while rc < len(file_r_lines):
                            if rc==0:
                                file_w.write('[')                        
                            if rc==len(file_r_lines)-1:
                                file_w.write(file_r_lines[rc].replace('}','}]'))                        
                            else:
                                file_w.write(file_r_lines[rc].replace('}','},'))                        
                            rc=rc+1
                    else:
                        file_w.writelines(file_r_lines)
                    
                    corrected_json_files_lst.append(os.path.join(r, 'corrected_'+file))
                    read_flag=1
                except Exception as e:                
                    print(str(e))
                
                finally:
                    file_r.close()
                    file_w.close()
            if read_flag==1:
                print(os.path.join(r,file))
                os.system("rm "+os.path.join(r, file))   
    print("Correcting json files completed")
    return corrected_json_files_lst

def send_email(subj_text,msg_text):

    msg = MIMEMultipart('alternative')
    msg['Subject'] = subj_text
    from_email = utils.getini('Email', 'FromAddress')
    #from_email = 'auditcheck@' + ut.getini('Environment', 'Environment')
    to_email = ut.getini('Email', 'DSNotifyError') + ',' + ut.getini('Email', 'AmFamNotifyInfo', default="") 
    to_list = to_email.split(',')
    #print('From: {}, To: {}'.format(from_email, to_email))
    msg['From'] = from_email            
    msg['To'] = to_email
    html = msg_text
    if len(html) > 0:
        html += '<p>[%d] %s</p>' % (msg_text)
        msg.attach(MIMEText('<html><body><head></head>%s</body></html>' % html, 'html'))
        if ut.getsmtp() is not None:
            for rec in to_list:
                ut.getsmtp().sendmail(from_email, rec, msg.as_string())

def check_args(argv):
    if len(argv) == 4:
        return argv[1], argv[2], "INIT_LOAD", argv[3]    
    else:
        print('Usage: Load_BC_EDDS_INITIAL_LOAD.py SOURCE TABLE_NAME ENVIRONMENT Target_Table')
        sys.exit(1)

def connect_api(environment):
    # Initialize API
    urllib3.disable_warnings()
    edds_tenant_id = utils.getinipath('E1P_API/{}/TENANT_ID'.format(environment))
    edds_client_id = utils.getinipath('E1P_API/{}/CLIENT_ID'.format(environment))
    edds_client_secret = utils.getinipath('E1P_API/{}/CLIENT_SECRET'.format(environment))
    endpoint = utils.getinipath(f'E1P_API/{environment}/ENDPOINT', default='')
    if edds_tenant_id and edds_tenant_id and edds_client_id:
        if endpoint:
            print(f'Using endpoint {endpoint}')
            client = pyedds.client(service_name="outbound",
                                   edds_tenant_id=edds_tenant_id,
                                   edds_client_id=edds_client_id,
                                   edds_client_secret=edds_client_secret,
                                   endpoint_root=endpoint,
                                   verify=False)
        else:
            client = pyedds.client(service_name="outbound",
                                   edds_tenant_id=edds_tenant_id,
                                   edds_client_id=edds_client_id,
                                   edds_client_secret=edds_client_secret,
                                   edds_env=environment,
                                   verify=False)
        time.sleep(1)
        return client
    else:
        return None


def verify_source_table(environment,source1, table1):
    client = connect_api(environment)
    if client:
        #print('Pinging client...', end='')
        print(client.ping())
        # Get sources:
        sources = client.sources()
        source_check=0        
        for source in sources:
            if len(source) > 0:
                if source.upper().strip(' ')==source1.upper().strip(' '):
                    source_check=1
                else:
                    continue                
                for table in client.tables(source=source):
                    if table.get('name').upper().strip(' ')==table1.upper().strip(' ') and source_check==1:
                        return True
    print("Table or Source does not exist")
    sys.exit(0)

def get_key_value(key):
    #Get the values from config file
    value = ut.getinipath(key, None)
    if not value:
        print('Could not find value for key {}'.format(key))
        return None       
    return value

# Connects to API, downloads all JSON and stores in temp file
def init_load_dump_json(source, table_name, environment):
    # Get scratch folder from config
    scratch_dir = str(get_key_value('/Environment/Scratch')) + "/" + table_name + '_{}'.format(datetime.now().strftime('%Y%m%d%H%M%S%f'))
    epoch = get_last_epoch(source, table_name)

    try:
        client = connect_api(environment)
        if client:
            count = 0
            fp = ""
            # for file in client.full(source=source, table=table_name):
            for line in client.since(source=source, table=table_name, from_dt=epoch,latest=True):
                if count == 0:
                    if not os.path.exists(scratch_dir):
                        os.makedirs(scratch_dir)
                    scratch_name = table_name + '_' + str(datetime.now().strftime('%Y%m%d%H%M%S%f')) + '.json'
                    filename = os.path.sep.join((scratch_dir, scratch_name))
                    fp = open(filename, 'w')

                    # Write to file
                fp.write(line)
                fp.write("\n")
                count += 1
                if (count % 100) == 0:
                    print('{} rows fetched from API'.format(count))
            if count > 0:
                fp.close()
            else:
                print('No New Records read from source')
                sys.exit(0)

            print('API fetch completed for {}/{}: {} files written to {}'.format(source, table_name, count, filename))
            return scratch_dir
        else:
            print('Could not connect to API')
            return None
    except OSError as e:
        print('Error writing to file {}'.format(filename))
        print(e)
        return None

# Connects to API, downloads all JSON and stores in temp file
def audit_load_dump_json(source, table_name, environment):
    # Get scratch folder from config
    scratch_dir = str(get_key_value('/Environment/Scratch')) + "/" + table_name + '_{}'.format(datetime.now().strftime('%Y%m%d%H%M%S%f'))
    epoch = get_last_epoch(source, table_name)

    try:
        client = connect_api(environment)
        if client:
            count = 0
            fp = ""
            # for file in client.full(source=source, table=table_name):
            #with_count=True
            for line in client.files(source=source, table=table_name, from_dt=epoch,with_count=True,latest=True):
                #print(line)
                if count == 0:
                    if not os.path.exists(scratch_dir):
                        os.makedirs(scratch_dir)
                    scratch_name = table_name + '_' + str(datetime.now().strftime('%Y%m%d%H%M%S%f')) + '.json'
                    filename = os.path.sep.join((scratch_dir, scratch_name))
                    fp = open(filename, 'w')

                    # Write to file
                fp.write(line)
                fp.write("\n")
                count += 1
                if (count % 100) == 0:
                    print('{} rows fetched from API'.format(count))
            if count > 0:
                fp.close()
            else:
                sys.exit(0)

            print('API fetch completed for {}/{}: {} files written to {}'.format(source, table_name, count, filename))
            return scratch_dir
        else:
            print('Could not connect to API')
            return None
    except OSError as e:
        print('Error writing to file {}'.format(filename))
        print(e)
        return None


def get_last_epoch(source, table_name):
    sql = '''select nvl(max(epoch)+1, 0) as epoch from datahub_edds.EDDS_BC_CONTROL 
             where SOURCE_FOLDER = :source and SOURCE_TABLE_NAME = :table_name'''    
    epoch = g_cursor.execute(sql, {'source': source, 'table_name': table_name}).fetchone()[0]
    if epoch == 0:
        epoch = MIN_EPOCH    
    return str(epoch).zfill(13)


def get_cycle_id():

    sql = """select cycle_id from datahub_md.etl_cycle where src_system_cd = :src_system_cd and cycle_status = 'Running'"""
    result = g_cursor.execute(sql, {'src_system_cd': SRC_SYSTEM_CD}).fetchall()

    if len(result) == 0:
        raise GeneralException("Could not get cycle_id from src_system_cd '{}' - check DATAHUB_MD.ETL_CYCLE".format(SRC_SYSTEM_CD))
    else:
        return int(result[0][0])

def load_to_audit(source, table_name, epoch, success_records, audit_total_rows,oracle_table_name):


    SOURCE_FOLDER=source
    SOURCE_TABLE_NAME=table_name
    LOAD_TS="TO_TIMESTAMP('"+str(datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'))+"','YYYY-MM-DD HH24:MI:SS.FF')"
    EPOCH=epoch
    ETL_CYCLE_ID= str(get_cycle_id())

    df_audit=pd.DataFrame()

    df_audit['SOURCE_FOLDER']=[SOURCE_FOLDER]
    df_audit['SOURCE_TABLE_NAME']=[SOURCE_TABLE_NAME]
    df_audit['LOAD_TS']=[LOAD_TS]
    df_audit['EPOCH']=[EPOCH]
    df_audit['ETL_CYCLE_ID']=[ETL_CYCLE_ID]
    df_audit['SUCCESS_RECORDS']=[success_records]
    df_audit['TARGET_SCHEMA'] = [oracle_table_name.split('.')[0]]
    df_audit['TARGET_TABLE_NAME'] = [oracle_table_name.split('.')[1]]
    df_audit['AUDIT_API_RECORDS'] = [audit_total_rows]

    cols = ",".join([str(i) for i in df_audit.columns.tolist()])
    # Insert DataFrame records one by one.

    for i,row in df_audit.iterrows():
       
        sql = "INSERT INTO " + 'DATAHUB_EDDS.EDDS_BC_CONTROL' + " (" + cols + ") VALUES " + str(tuple(row)).replace('"TO_TIMESTAMP','TO_TIMESTAMP').replace('HH24:MI:SS.FF\')"','HH24:MI:SS.FF\')')                
        try:
            g_cursor.execute(sql)            
        except:
            pass

def get_next_sequence():

    sql = 'select DATAHUB_HDS.E1P_BC_SEQ.nextval from dual'    
    seq = g_cursor.execute(sql).fetchone()[0]    
    return seq

def get_timestamp_cols(table_name):
    
    sql="select LISTAGG((CASE WHEN COLUMN_NAME like 'HEADER__%' THEN LOWER(COLUMN_NAME ) ELSE COLUMN_NAME  END),',') WITHIN GROUP (ORDER BY TABLE_NAME)  from all_tab_columns  WHERE OWNER='DATAHUB_EDDS' AND TABLE_NAME='"+table_name.split('.')[1]+"' AND COLUMN_NAME NOT LIKE 'ETL_%' AND DATA_TYPE LIKE 'TIMESTAMP%' "
    g_cursor.execute(sql)
    df1 = DataFrame(g_cursor.fetchall())
    columns_existing=str(df1.iloc[0,0]).strip(' ')
    columns_existing=columns_existing.split(',')
    return columns_existing

def main():

    try:
        global g_connection, g_cursor
        try:
            g_connection = cx_Oracle.connect(ut.getdblogin())
            #environment = ut.getinipath('E1P_API/DefaultENV')
            print("Connection established successfully")
        except Exception as e:
            print("Error during establishment of connection="+str(e))            

        try:
            g_cursor = g_connection.cursor()
            print("cursor established successfully")
        except Exception as e:
            print("Error during establishment of cursor="+str(e))            

        #commented out to test logout from VPN
        #source, table_name, environment,load_type,oracle_table_name = check_args(sys.argv)
        source, table_name,load_type,oracle_table_name = check_args(sys.argv)

        verify_source_table(environment,source, table_name)

        print("source and table exists and retreiving the data")

        #commented out to test logout from VPN
        dirname=""
        if load_type.upper().strip(' ')=="INIT_LOAD":
            dirname=init_load_dump_json(source,table_name,environment)
        else:
            dirname = inc_load_dump_json(source, table_name, environment)

        print("folder in which json files are being prepared:"+str(dirname))
        files_2_b_loaded=[]
        if dirname is not None and len(dirname) > 0:
            json_folder=dirname
            files_2_b_loaded=correct_json_files(json_folder)

        print(files_2_b_loaded)

        ## audit data extract from API

        audit_dirname=audit_load_dump_json(source, table_name, environment)
        print("folder in which audit api data files are being prepared:"+str(audit_dirname))
        audit_files=[]
        if audit_dirname is not None and len(audit_dirname) > 0:
            json_folder=audit_dirname
            audit_files=correct_json_files(json_folder)

        ## audit data extract from API

        print("oracle table name to which extracted data is to be loaded:"+str(oracle_table_name))

        if len(files_2_b_loaded) > 0:
            print('test')
            fload_counter=0
            Max_epoch=0
            load_status=[]
            for filename in files_2_b_loaded:

                print("Processing of "+filename+" started")

                df=read_json(filename) 

                if str(type(df))=="<class 'pandas.core.series.Series'>":
                    df = pd.DataFrame([df])

                print("completed reading of content from json file")    

                ## audit check   
                print("procesing of audit file "+str(audit_files[0]))
                auditdf=read_json(str(audit_files[0])) 
                os.system("rm "+str(audit_files[0]))
                os.system("rmdir "+audit_dirname) 
                #print(len(auditdf))
                #print(auditdf.columns)
                #print(auditdf)
                if str(type(auditdf))=="<class 'pandas.core.series.Series'>":
                    auditdf = pd.DataFrame([auditdf])
                #audit_total_rows=auditdf['rows'].sum()
                audit_total_rows=len(auditdf)
                print('Audit Total count:',audit_total_rows)
                if audit_total_rows==len(df) or str(oracle_table_name)=='DATAHUB_EDDS.EDDS_BC_POLICY' or audit_total_rows!=len(df):
                    pass
                else:
                    send_email("Mismatch in the number of rows retrieved from Billing Centers DQ framework API:Refer to (https://amfament.atlassian.net/wiki/spaces/E1PD/pages/411012248/Outbound+Client) to number of rows given by API-" + str(audit_total_rows), "Number of rows read by API " + str(len(df))+"\n"+"Number of rows given by API "+str(audit_total_rows) + " .There is Discrepency Between rows read from AWS s3 Bucket Vs rows in JSON .Please investigate and take necessary action")
                    sys.exit(0)                        
                ## audit check 

                ## converting all columns to strings

                ETL_CREATE_DTS = "TO_TIMESTAMP('" + str(datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')) + "','YYYY-MM-DD HH24:MI:SS.FF')"
                ETL_CYCLE_ID=get_cycle_id()                
                #ETL_UPDATE_DTS = "TO_TIMESTAMP('" + str(datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')) + "','YYYY-MM-DD HH24:MI:SS.FF')"

                df['ETL_CREATE_DTS']=ETL_CREATE_DTS
                df['ETL_CYCLE_ID']=ETL_CYCLE_ID
                #df['ETL_UPDATE_DTS']=ETL_UPDATE_DTS                
                df['EPOCH'] = df["__s3LastModifiedEpoc"]
                EPOCH = max(list(df["__s3LastModifiedEpoc"]))
                Max_epoch = EPOCH                

                ts_cols=get_timestamp_cols(oracle_table_name)
                for tsci in ts_cols:
                    try:
                        df[tsci]=df[tsci].astype(str)                        
                        df[tsci] = df[tsci].map(lambda ts: None if str(ts) == 'None' or str(ts) =='NaT' else "TO_TIMESTAMP('" + str(ts) + "','YYYY-MM-DD HH24:MI:SS.FF')")
                    except Exception as e:
                        print("Converting time stamp col "+str(tsci)+" with error "+str(e))

                load_status=load_to_db(df,oracle_table_name)

                if load_status[0]==True:
                    fload_counter=fload_counter+1
                    os.system("rm "+filename)  
                    load_to_audit(source,table_name,Max_epoch,load_status[1],audit_total_rows,oracle_table_name)
                    g_connection.commit()
                    
                else:
                    trunc_statement="truncate table "+oracle_table_name
                    g_cursor.execute(trunc_statement)
                
                print("Processing of "+filename+" completed")  
                
            if fload_counter==len(files_2_b_loaded):
                os.system("rmdir "+dirname)                  
            
            ### load to audit table       
            # load_to_audit(source,table_name,Max_epoch,load_status[1],load_status[2])
            ### load to audit table       

            print("completed loading of files to database")
            g_connection.commit()

    except cx_Oracle.DatabaseError as e:
        print('Database error: {}'.format(e))

    if g_cursor:
        g_cursor.close()
    if g_connection:
        g_connection.close()

main()