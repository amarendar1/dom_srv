###########--------- Worked code

# import json
# from pprint import pprint
# from pandas.io.json import json_normalize

# with open(r'C:\Users\asrilekh\Desktop\test_nest_json.json') as f:
#     data=json.load(f)
#     # pprint(data)
#     df=json_normalize(data)
#     print(df)
#     df.to_csv(r'C:\Users\asrilekh\Desktop\test_nest_json.csv',index=False)

###########--------- Worked code



import json
from pprint import pprint
from pandas import json_normalize

def flatten_json(y):
    out={}
    def flatten(x,name=''):
        if type(x) is dict:
            for a in x:
                    flatten(x[a],name+a+"_")
        elif type(x) is list:
            i=0
            for a in x:
                flatten(a,name+str(i)+"_")
                i +=1
        else:
            out[name[:-1]]=x
    flatten(y)
    return out

def main(filename,opfn):
    fp=open(filename,'r')
    rl=fp.readlines()
    fp.close()
    # print(rl)
    rls=[]
    for rli in rl:
        s1=str(rli).replace('\n','').replace('"{','{').replace('}"','}').replace('\"','"').replace("\t",'').replace('  ',' ')
        for ci in ['{','}','[',']',',','"',"'",":"]:
            s1=s1.replace(' '+ci,ci).replace(ci+' ',ci)
        rls.append(s1)
    raw_json_ext=''.join(rls)
    fp = open(filename, 'w')
    fp.write(raw_json_ext)
    fp.close()
    fp = open(filename, 'r')
    data=json.load(fp)
    flat = flatten_json(data)
    # pprint(data)
    df = json_normalize(flat)
    print(df)
    df.to_csv(opfn, index=False)

main(r'C:\DomainServices\parse_testing\AUTOPOLICY_PC_ANALYTICAL_JSON.JSON',r'C:\DomainServices\parse_testing\AUTOPOLICY_PC_ANALYTICAL_JSON.csv')