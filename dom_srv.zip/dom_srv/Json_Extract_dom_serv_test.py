import utils as ut
import cx_Oracle
from sqlalchemy import types, create_engine
import pandas as pd
import time
import urllib3
from datetime import datetime
import sys
import os
from pandas import DataFrame
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import json
# import utils_1 as ut



global g_connection, g_cursor

try:
    g_connection = cx_Oracle.connect(ut.getdblogin())
except Exception as e:
    print("Error during establishment of connection=" + str(e))
    print("Connection established successfully")

try:
    g_cursor = g_connection.cursor()
except Exception as e:
    print("Error during establishment of cursor=" + str(e))
    print("cursor established successfully")

global engine

engine = ""
## creating oracle engine
try:
    engine = ut.getengine()
except Exception as e:
    print(str(e))

df = pd.DataFrame()


# COLS = "SELECT JSON FROM DATAHUB_EDDS.EDDS_PC_JSON_STORE WHERE JSON_ID=1082900"
# df_tables = pd.read_sql_query(COLS, engine)
# print(type(df))
# print(df_tables)
# # print(df.columns)
# print(df.dtypes)
# df.to_csv('json_extract_dom_serv_test.json')
# fp=open('json_extract_dom_serv_test.json','w')
# fp.write(df.iloc[0])
# fp.close()

#
#
#
#
def OutputTypeHandler(cursor, name, defaultType, size, precision, scale):
    if defaultType == cx_Oracle.CLOB:
        return cursor.var(cx_Oracle.LONG_STRING, arraysize = cursor.arraysize)
    elif defaultType == cx_Oracle.BLOB:
        return cursor.var(cx_Oracle.LONG_BINARY, arraysize = cursor.arraysize)


g_connection.outputtypehandler = OutputTypeHandler

g_cursor.execute("""
        SELECT JSON FROM DATAHUB_EDDS.EDDS_PC_JSON_STORE WHERE JSON_ID=1082900""")
json_data = [json.loads(s) for s, in g_cursor]
print(json_data)
